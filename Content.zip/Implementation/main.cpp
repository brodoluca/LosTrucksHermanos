#include <iostream>
#include "TruckPlatoon.hpp"


int main()
{
    
    TruckPlatoon::StartSimulation(1);
    return 0;
}