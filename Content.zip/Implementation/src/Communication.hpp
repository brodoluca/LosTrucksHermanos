#pragma once
#include "Event.hpp"
#include "Truck.hpp"

#include "utils/PlatoonTypes.hpp"

///In case the receiver is 0 we talk about broadcasting. 
/// In general we use the truck id to define who the sender and the receiver is




    

