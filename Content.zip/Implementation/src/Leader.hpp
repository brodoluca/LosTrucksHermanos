#ifndef Leader_HPP
#define Leader_HPP
//#pragma once
#include "Truck.hpp"

class LeaderTruck : public Truck
{
public:
    LeaderTruck();
};



#endif