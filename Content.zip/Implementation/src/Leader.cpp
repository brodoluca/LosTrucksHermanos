#include "Leader.hpp"

LeaderTruck::LeaderTruck()
{
    this->_id = 1;
}