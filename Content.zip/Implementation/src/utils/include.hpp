#pragma once
#include <omp.h>
#include <iostream>

